# Shreya Shukla — Academic Website

A lightweight static academic website designed for GitHub Pages.

## Deploy

1. Create or use the repository `shreyaalkuhs.github.io`.
2. Upload `index.html` to the root of the repository.
3. In GitHub, go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save.

The site should then be available at:

https://shreyaalkuhs.github.io

## Editing

Everything is contained in `index.html`, including the styling, so you can edit a single file.